﻿namespace CareerCrafter.Repositories
{
    public interface IAuthenticationService
    {
        Task Logout();
    }

}
