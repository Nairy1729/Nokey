﻿namespace CareerCrafter.Models
{
    public class ForgotPasswordRequest
    {
        public string Email { get; set; }
    }
}
