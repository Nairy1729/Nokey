﻿using Microsoft.AspNetCore.Identity;

namespace CareerCrafter.Authentication
{
    public class ApplicationUser : IdentityUser
    {
    }
}
